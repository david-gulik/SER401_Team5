package edu.ser222.m01_03;

/**
 * CompletedOrderedList represents an implementation of an ordered list that builds on
 * CompletedList.
 *
 * @author (Lindy Crain), Acuna
 * @version (1)
 * Completion Time: ~4 hours
 */
public class CompletedOrderedList<T extends Comparable<T>> extends CompletedList<T>
         implements OrderedListADT<T> {
	
	private DoubleLinearNode<T> added;
	
	//constructor
	public CompletedOrderedList() {
		added = null;
	}

	@Override
	public void add(T element) throws NullPointerException {
		DoubleLinearNode<T> current = null;
		DoubleLinearNode<T> prior = null;
		DoubleLinearNode<T> next = null;
		added = new DoubleLinearNode<>(element);
		
		if(element == null) {
			throw new NullPointerException("Item to be added is null");
		}
		
		//check if empty
		else if(isEmpty()) {
			head = added;
			tail = added;
			head.setPrior(null);
			tail.setNext(null);
		}
		
		//check if element is less than or equal to head
		else if(added.getElement().compareTo(head.getElement()) == -1 || added.getElement().compareTo(head.getElement()) == 0) {
			next = head;
			head = added;
			head.setNext(next);
			next.setPrior(head);
		}
		
		else if(added.getElement().compareTo(tail.getElement()) == 1) {
			prior = tail;
			tail = added;
			tail.setPrior(prior);
			tail.setNext(null);
			prior.setNext(tail);
		}
		
		//otherwise iterate through and check each node
		else {
			current = head;
			while(current.getNext() != null && added.getElement().compareTo(current.getElement()) == 1) {
				prior = current;
				current = current.getNext();	
			}
			
			current.setPrior(added);
			added.setNext(current);
			current = added;
			current.setPrior(prior);
			prior.setNext(current);
			
		}
		n++;
		modCount++;
	}
}
