package edu.ser222.m01_03;

public class DoubleLinearNode<T> { 
		private DoubleLinearNode<T> next;
		private DoubleLinearNode<T> prior;
		private T element;
		
		public DoubleLinearNode(T elem) {
			next = null;
			prior = null;
			element = elem;
		}
		
		public DoubleLinearNode<T> getNext() {
			return next;
		}
		
		public DoubleLinearNode<T> getPrior() {
			return prior;
		}
		
		public void setNext(DoubleLinearNode<T> node) {
			next = node;
		}
		
		public void setPrior(DoubleLinearNode<T> node) {
			prior = node;
		}
		
		public T getElement() {
			return element;
		}
		
		public void setElement(T elem) {
			element = elem;
		}

	}