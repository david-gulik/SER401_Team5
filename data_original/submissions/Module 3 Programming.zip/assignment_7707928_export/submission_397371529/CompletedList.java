package edu.ser222.m01_03;

import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * CompletedList represents an implementation of a list.
 *
 * @author (Lindy Crain), Acuna
 * @version (1)
 * Completion Time: ~11 hours
 */
public class CompletedList<T> implements ListADT<T>, Iterable<T> {
	
	protected int n;
	protected int modCount;
	protected DoubleLinearNode<T> head;
	protected DoubleLinearNode<T> tail;
	
	//constructor
	public CompletedList() {
		n = 0;
		modCount = 0;
		head = null;
		tail = null;
	}

	@Override
	public T removeFirst() throws NoSuchElementException {
		T removed = null;
		if(isEmpty()) {
			throw new NoSuchElementException("The queue is empty");
		}
		
		else if(n == 1) {
			removed = head.getElement();
			head = null;
			tail = null;
			n--;
			modCount++;
		}
		else {
			removed = head.getElement();
			head = head.getNext();
			head.setPrior(null);
			n--;
			modCount++;
		}
		
		return removed;
	}

	@Override
	public T removeLast() throws NoSuchElementException {
		T removed = null;
		if(isEmpty()) {
			throw new NoSuchElementException("The queue is empty");
		}
		
		else if(n == 1) {
			removed = tail.getElement();
			head = null;
			tail = null;
			n--;
			modCount++;
		}
		
		else {
			removed = tail.getElement();
			tail = tail.getPrior();
			tail.setNext(null);
			n--;
			modCount++;
		}
		
		return removed;
	}

	@Override
	public T remove(T element) throws NoSuchElementException {
		T removed = null;
		DoubleLinearNode<T> current = null;
		DoubleLinearNode<T> prior = null;
		DoubleLinearNode<T> next = null;
		
		if(isEmpty()) {
			throw new NoSuchElementException("The queue is empty");
		}
		
		else if (n == 1) {
			removed = head.getElement();
			head = null;
		}
		
		else if(head != null && element.equals(head.getElement())) {
			removed = head.getElement();
			head = head.getNext();
			head.setPrior(null);
		}
		
		else if(tail != null && element.equals(tail.getElement())) {
			removed = tail.getElement();
			tail = tail.getPrior();
			tail.setNext(null);
		}
		
		else {
			current = head;
			while (current != null && !element.equals(current.getElement())) {
				prior = current;
				current = current.getNext();
			}
			
			if(current == null)  {
				throw new NoSuchElementException("The element is not in the list");
			}

			removed = current.getElement();
			current = current.getNext();
			current.setPrior(prior);
			prior.setNext(current);
		}
		
		n--;
		modCount++;
		return removed;
	
	}

	@Override
	public T first() {
		if(isEmpty()) {
			throw new NoSuchElementException("The queue is empty");
		}
		return head.getElement();
	}

	@Override
	public T last() {
		if(isEmpty()) {
			throw new NoSuchElementException("The queue is empty");
		}
		return tail.getElement();
	}

	@Override
	public boolean contains(T target) {
		DoubleLinearNode<T> current = null;
		DoubleLinearNode<T> prior = null;
		DoubleLinearNode<T> next = null;
		
		if(head != null && target.equals(head.getElement())) {
			return true;
		}
		
		else if(tail != null && target.equals(tail.getElement())) {
			return true;
		}
		
		else {
			current = head;
			while(current != null && !target.equals(current.getElement())) {
				prior = current;
				current = current.getNext();
			}
			
			if(current == null)  {
				return false;
			}	
			
			return true;
		}
	}

	@Override
	public boolean isEmpty() {
		return head == null;
	}

	@Override
	public int size() {
		return n;
	}

	@Override
	public Iterator<T> iterator() {
		return new ListIterator();
	}
	
	@Override
	public String toString() {
		String queue = "";
		
		if(isEmpty()) {
			queue = "empty";
		}
		
		DoubleLinearNode<T> current = head;
		while(current != null) { 
			queue += current.getElement() + " ";
			current = current.getNext();
		}
		return queue;
	}
	
	class ListIterator implements Iterator<T> {
		
		private final int modCounted = modCount;
        private DoubleLinearNode<T> iter = head;
        
        @Override
        public boolean hasNext() throws ConcurrentModificationException {
        	if(modCount != modCounted) {
                throw new ConcurrentModificationException("Concurrent modification");
        	}
        	
            return iter != null; 
        }
        
        @Override
        public T next() throws NoSuchElementException {
        	if (!hasNext())
        		throw new NoSuchElementException("The list is empty");

	        T element = iter.getElement();
	        iter = iter.getNext();
	        
	        return element;
        }
        
        @Override
        public void remove() throws UnsupportedOperationException {
        	throw new UnsupportedOperationException("Unsupported Operation");        	
        	
        }
  }
		
}