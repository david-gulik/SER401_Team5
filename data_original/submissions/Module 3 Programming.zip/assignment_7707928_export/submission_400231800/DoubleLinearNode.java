package edu.ser222.m01_03;

public class DoubleLinearNode<T> {
    private DoubleLinearNode next;
    private DoubleLinearNode previous;
    private T element;

    public DoubleLinearNode() {
        next = null;
        previous = null;
        element = null;
    }

    public DoubleLinearNode(T elem) {
        next = null;
        previous = null;
        element = elem;
    }

    public DoubleLinearNode getNext() {
        return next;
    }

    public void setNext(DoubleLinearNode node) {
        next = node;
    }

    public DoubleLinearNode getPrevious() {
        return previous;
    }

    public void setPrevious(DoubleLinearNode node) {
        previous = node;
    }

    public T getElement() {
        return element;
    }

    public void setElement(T elem) {
        element = elem;
    }

}