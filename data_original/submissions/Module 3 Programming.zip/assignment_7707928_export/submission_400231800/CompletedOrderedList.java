package edu.ser222.m01_03;

/**
 * CompletedOrderedList represents an implementation of an ordered list that builds on
 * CompletedList.
 *
 * @author Bailey Bourque, Acuna
 * @version 1.0.0
 */
public class CompletedOrderedList<T extends Comparable<T>> extends CompletedList<T>
         implements OrderedListADT<T> {

    @Override
    public void add(T element) throws NullPointerException {
        if (element == null) {
            throw new NullPointerException();
        }
        DoubleLinearNode<T> current = head;
        DoubleLinearNode<T> previous = null;
        DoubleLinearNode<T> newNode = new DoubleLinearNode<T>(element);
    
        // Find the correct insertion point
        while (current != null && element.compareTo(current.getElement()) > 0) {
            previous = current;
            current = current.getNext();
        }
    
        // Insert the new node
        if (previous == null) {
            head = newNode;
        } else {
            previous.setNext(newNode);
        }
        if (current == null) {
            tail = newNode;
        } else {
            current.setPrevious(newNode);
        }
        newNode.setNext(current);
        newNode.setPrevious(previous);
    
        // Update the count and modification counter
        count++;
        modChange++;
    }
}
