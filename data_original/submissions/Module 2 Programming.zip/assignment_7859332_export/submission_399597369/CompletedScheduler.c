/**
* Course management program
*
* Completion time: 630m
*
* @author Lindy Crain
* @version 1
*/

////////////////////////////////////////////////////////////////////////////////
//INCLUDES
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

////////////////////////////////////////////////////////////////////////////////
//MACROS: CONSTANTS
typedef enum {CSE, EEE, EGR, SER} Subject;


////////////////////////////////////////////////////////////////////////////////
//DATA STRUCTURES
typedef struct courseNode {
  Subject subject;
  int number;
  char teacher[1024];
  int credits;
  struct courseNode* next;
} courseNode;


////////////////////////////////////////////////////////////////////////////////
//GLOBAL VARIABLES
int totalCredits = 0;

//place to store course information
struct courseNode* course_collection = NULL;

////////////////////////////////////////////////////////////////////////////////
//FORWARD DECLARATIONS
void branching(char option);
void course_insert();
void schedule_print();
void course_drop();
void schedule_load();
void schedule_save();

//main entry point. Starts the program by displaying a welcome and beginning an 
//input loop that displays a menu and processes user input. Pressing q quits.      
int main() {
	char input_buffer;

	printf("\n\nWelcome to ASU Class Schedule\n");

	schedule_load();

	//menu and input loop
	do {
		printf("\nMenu Options\n");
		printf("------------------------------------------------------\n");
		printf("a: Add a class\n");
		printf("d: Drop a class\n");
		printf("s: Show your classes\n");
		printf("q: Quit\n");
		printf("\nTotal Credits: %d\n\n", totalCredits);
		printf("Please enter a choice ---> ");

		scanf(" %c", &input_buffer);

		branching(input_buffer);
	} while (input_buffer != 'q');

	schedule_save();

	return 0;
}

//takes a character representing an inputs menu choice and calls the appropriate
//function to fulfill that choice. display an error message if the character is
//not recognized.
void branching(char option) {
	switch (option) {
	case 'a':
		course_insert();
		break;

	case 'd':
		course_drop();
		break;

	case 's':
		schedule_print();
		break;

	case 'q':
		// main loop will take care of this.
		break;

	default:
		printf("\nError: Invalid Input.  Please try again...");
		break;
	}
}

void course_insert() {
    Subject subj;
    int num;
    char teacher[1024];
    int credits;

    printf("Enter Subject (0 - CSE | 1 - EEE | 2 - EGR | 3 - SER):\n");
    scanf("%d", &subj);

    printf("Enter Course Number: \n");
    scanf("%d", &num);

    printf("Enter teacher: \n");
    scanf("%s", teacher);

    printf("Enter credits: \n");
    scanf("%d", &credits);

    struct courseNode* course = (struct courseNode*)malloc(sizeof(struct courseNode));

    if (course == NULL) {
        printf("Memory allocation for course was not successful.\n");
        return;
    }

    course->subject = subj;
    course->number = num;
    strcpy(course->teacher, teacher);
    course->credits = credits;
    course->next = NULL;

    struct courseNode* temp = course_collection;

    while (temp) {
        if (temp->subject == subj && temp->number == num) {
            printf("Course already exists and was not added to the list.\n");
            free(course);
            return;
        }
        temp = temp->next;
    }

    if (course_collection == NULL || course_collection->subject > subj || 
        (course_collection->subject == subj && course_collection->number > num)) {
        course->next = course_collection;
        course_collection = course;
    }
    else {
        temp = course_collection;
        while (temp->next != NULL && 
               (temp->next->subject < subj || 
               (temp->next->subject == subj && temp->next->number < num))) {
            temp = temp->next;
        }

        course->next = temp->next;
        temp->next = course;
    }

    totalCredits += credits;
    const char* subjects[] = {"CSE", "EEE", "EGR", "SER"};
    printf("%s%d has been added.\n", subjects[subj], num);
}

void course_drop() {
    if (course_collection == NULL) {
        printf("No courses in list. Unable to drop a course.\n");
        return;
    }

  Subject subj;
  int num;
  struct courseNode* temp = course_collection;
  struct courseNode* prev = NULL;

  printf("Enter Subject (0 - CSE | 1 - EEE | 2 - EGR | 3 - SER):\n");
  scanf("%d", &subj);
  printf("Enter Number:\n");
  scanf("%d", &num);


  while(temp != NULL && (temp->subject != subj || temp->number != num)) {
    prev = temp;
    temp = temp->next;
    }

    if (temp) {
      if (prev) {
        prev->next = temp->next;
      }

      else {
        course_collection = temp->next;
      }

      totalCredits -= temp->credits;

        char subjects[4];

        switch (temp->subject) {
            case CSE:
                strcpy(subjects, "CSE");
            break;
            case EEE:
                strcpy(subjects, "EEE");
            break;
            case EGR:
                strcpy(subjects, "EGR");
            break;
            case SER:
                strcpy(subjects, "SER");
            break;
        }

      printf("%s%d has been dropped.\n", subjects, temp->number);

      free(temp);
    }

    else {
      printf("Course was not found.\n");
    }
}

void schedule_print() {

  if(course_collection == NULL) {
    	printf("No courses in the schedule yet.\n");
        return;
 	}

  struct courseNode* temp = course_collection;

  printf("Course Schedule: \n");
  printf("--------------------------\n");
  printf("Subj/Num  Credits  Teacher\n");

  while (temp) {
    char subjects[4];

    switch (temp->subject) {
      case CSE:
        strcpy(subjects, "CSE");
        break;
      case EEE:
        strcpy(subjects, "EEE");
        break;
      case EGR:
        strcpy(subjects, "EGR");
        break;
      case SER:
        strcpy(subjects, "SER");
        break;
      }
	printf("%s%d %d %s\n", subjects, temp->number, temp->credits, temp->teacher);
    temp = temp->next;
  }
}

void schedule_load() {
  FILE* file = fopen("course_schedule.txt", "r");

  if (file == NULL) {
      printf("No schedule found. Start one by adding courses from the main menu.");
      return;
  }


    char subjects[4];
    int num;
    int credits;
    char teacher[1024];

    while (fscanf(file, "%3s%d %d %1023[^\n]", subjects, &num, &credits, teacher) == 4) {

        Subject subj;
        if (strcmp(subjects, "CSE") == 0) {
            subj = CSE;
        }
        else if (strcmp(subjects, "EEE") == 0) {
            subj = EEE;
        }
        else if (strcmp(subjects, "EGR") == 0) {
            subj = EGR;
        }
        else  {
            subj = SER;

        }



      struct courseNode* course = (struct courseNode*)malloc(sizeof(struct courseNode));

      if (course == NULL) {
		printf("Memory allocation for course was not successful.\n");
        fclose(file);
        return;
      }

      course->subject = subj;
      course->number = num;
      strcpy(course->teacher, teacher);
      course->credits = credits;
      course->next = NULL;

      if (course_collection == NULL || course_collection->subject > subj || (course_collection->subject == subj && course_collection->number > num)) {
        course->next = course_collection;
        course_collection = course;
      }

      else {
        struct courseNode* temp = course_collection;

        while(temp->next != NULL && (temp->next->subject < subj || (temp->next->subject == subj && temp->next->number < num ))) {
			temp = temp->next;
        }

      	course->next = temp->next;
      	temp->next = course;
      }

      totalCredits += credits;
  }
  fclose(file);
  printf("Schedule successfully loaded from file.\n");

}

void schedule_save() {
  FILE* file = fopen("course_schedule.txt", "w");

  if(file != NULL) {
    struct courseNode* temp = course_collection;

    while (temp) {
        char subjects[4];

        switch (temp->subject) {
            case CSE:
                strcpy(subjects, "CSE");
            break;
            case EEE:
                strcpy(subjects, "EEE");
            break;
            case EGR:
                strcpy(subjects, "EGR");
            break;
            case SER:
                strcpy(subjects, "SER");
            break;
        }

      fprintf(file, "%s%d %d %s\n", subjects, temp->number, temp->credits, temp->teacher);

        temp = temp->next;
    }
    fclose(file);
  }
}

