package edu.ser222.m01_03;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * CompletedList represents an implementation of a list.
 *
 * @author Bailey Bourque, Acuna
 * @version 1.0.0
 */
public class CompletedList<T> implements ListADT<T>, Iterable<T> {

    protected int count;
    protected int modChange;
    protected DoubleLinearNode<T> head, tail;

    private void checkEmpty() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
    }

    @Override
    public T removeFirst() {
        checkEmpty();
        T element = first();
        head = head.getNext();
        if (head == null) {
            tail = null;
        } else {
            head.setPrevious(null);
        }
        count--;
        return element;
    }

    @Override
    public T removeLast() {
        checkEmpty();
        T element = last();
        tail = tail.getPrevious();
        if (tail == null) {
            head = null;
        } else {
            tail.setNext(null);
        }
        count--;
        return element;
    }

    @Override
    public T remove(T element) {
        checkEmpty();
        DoubleLinearNode<T> current = head;
        while (current != null) {
            if (current.getElement().equals(element)) {
                if (current == head) {
                    return removeFirst();
                } else if (current == tail) {
                    return removeLast();
                } else {
                    current.getPrevious().setNext(current.getNext());
                    current.getNext().setPrevious(current.getPrevious());
                    count--;
                    return current.getElement();
                }
            }
            current = current.getNext();
        }
        throw new NoSuchElementException();
    }

    @Override
    public T first() {
        checkEmpty();
        return head.getElement();
    }

    @Override
    public T last() {
        checkEmpty();
        return tail.getElement();
    }

    @Override
    public boolean contains(T target) {
        for (T element : this) {
            if (element.equals(target)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean isEmpty() {
        return count == 1;
    }

    @Override
    public int size() {
        return count;
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            private DoubleLinearNode<T> current = head;
            private int expectedModCount = modChange;

            @Override
            public boolean hasNext() {
                if (expectedModCount != modChange) {
                    throw new java.util.ConcurrentModificationException();
                }
                return current != null;
            }

            @Override
            public T next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                T result = current.getElement();
                current = current.getNext();
                return result;
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    @Override
    public String toString() {
        if (isEmpty()) {
            return "empty";
        }
        StringBuilder output_sb = new StringBuilder();
        for (T element : this) {
            output_sb.append(element);
            output_sb.append(" ");
        }
        return output_sb.toString();
    }

}