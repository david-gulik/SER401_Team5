/**
* This program is a simple class schedule program that allows a user to add and drop classes.
*
* Completion time: 3 hours
*
* @author Bailey Bourque, Acuna
* @version 2025_01_15
*/

////////////////////////////////////////////////////////////////////////////////
//INCLUDES
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

////////////////////////////////////////////////////////////////////////////////
//MACROS: CONSTANTS

////////////////////////////////////////////////////////////////////////////////
//DATA STRUCTURES

enum Subject { CSE, EEE, EGR, SER};

struct courseNode {
    enum Subject subject;
    int course_number;
    char teacher[1024];
    int credit_hours;
    struct courseNode* next;
};

struct course_collection {
    struct courseNode* head;
};

////////////////////////////////////////////////////////////////////////////////
//GLOBAL VARIABLES

int total_credits = 0;
struct course_collection schedule = {NULL};

////////////////////////////////////////////////////////////////////////////////
//FUNCTION PROTOTYPES
void branching(char option);
void course_insert(struct course_collection* collection);
void course_drop(struct course_collection* collection);
void schedule_print(struct course_collection* collection);
void free_memory(struct course_collection* collection);
void schedule_save(struct course_collection* collection);
void schedule_load(struct course_collection* collection);

////////////////////////////////////////////////////////////////////////////////
//FUNCTION IMPLEMENTATIONS

char *subject_to_string(enum Subject subject) {
	/*
	Converts the subject enum to a string for printing
	*/
	switch (subject) {
	case SER:
		return "SER";
	case EGR:
		return "EGR";
	case CSE:
		return "CSE";
	case EEE:
		return "EEE";
	}
}

enum Subject string_to_subject(char* subject) {
	/*
	Converts the subject string to an enum for processing
	*/
	if (strcmp(subject, "SER") == 0) {
		return SER;
	} else if (strcmp(subject, "EGR") == 0) {
		return EGR;
	} else if (strcmp(subject, "CSE") == 0) {
		return CSE;
	} else if (strcmp(subject, "EEE") == 0) {
		return EEE;
	} else {
		printf("Error: Invalid subject %s\n", subject);
		exit(1);
	}
}

void insert_node(struct courseNode** head, struct courseNode* new_node) {
	struct courseNode** current = head;
	// Traverse the list to find the correct position to insert the new node based on subject and course number
	while (*current != NULL && ((*current)->subject < new_node->subject ||
			((*current)->subject == new_node->subject && (*current)->course_number < new_node->course_number))) {
		current = &(*current)->next;
	}
	new_node->next = *current; // Insert before current
	*current = new_node; // Update current to point to new_node
}

int node_exists(struct courseNode* head, struct courseNode* new_node) {
	struct courseNode* current = head;
	while (current != NULL) {
		if (current->subject == new_node->subject && current->course_number == new_node->course_number) {
			return 1;
		}
		current = current->next;
	}
	return 0;
}

void course_insert(struct course_collection* collection) {
	/*
	Adds courses to the collection and keeps it sorted. Orders by both subject and course number.
	For example, all CSE courses would show before SER courses, and SER222 would show before SER334.
	Populates the elements of the courseNode as shown below. Does not allow duplicate courses
	*/

    struct courseNode* new_node = (struct courseNode*)malloc(sizeof(struct courseNode));
    printf("What is the subject? (e.g. SER, EGR, CSE, EEE)?\n");
	char subject_input[4];
	scanf("%s", subject_input);
	new_node->subject = string_to_subject(subject_input);
    printf("What is the number (e.g. 240)?\n");
    scanf("%d", &new_node->course_number);
    printf("How many credits is the class (e.g. 3)?\n");
    scanf("%d", &new_node->credit_hours);
    printf("What is the name of the teacher?\n");
	scanf("%1023s", new_node->teacher);

    // Insert in sorted order
	if (node_exists(collection->head, new_node)) {
		printf("Error: Course already exists\n");
		free(new_node);
		return;
	} else {
		insert_node(&collection->head, new_node);
		total_credits += new_node->credit_hours;
	}

}

void schedule_print(struct course_collection* collection) {
    /*
    This function will display the contents of the course_collection
    list with format Subject Number Credits Teacher as shown.
    */
    struct courseNode* current = collection->head;
    printf("\n%-10s %-10s %-10s %-30s\n", "Subject", "Number", "Credits", "Teacher");
    printf("%-10s %-10s %-10s %-30s\n", "----------", "----------", "----------", "------------------------------");

    while (current != NULL) {
        printf("%-10s %-10d %-10d %-30s\n", subject_to_string(current->subject),
               current->course_number,
               current->credit_hours,
               current->teacher);
        current = current->next;
    }
}

void course_drop(struct course_collection* collection) {
	/*
	This function will prompt the user for a course by its subject and number.
	It then searches for the course in course_collection and removes it. Dropping a course
	is only allowed if the course exists in the collection, otherwise an error message will be displayed.
	*/
    struct courseNode* current = collection->head;
    struct courseNode* previous = NULL;

	char subject_input[4];
    printf("What is the subject? (e.g. SER, EGR, CSE, EEE) ");
	scanf("%s", subject_input);
	enum Subject subject = string_to_subject(subject_input);

    int course_number;
	printf("Enter number (e.g 100): ");
    scanf("%d", &course_number);

    while (current != NULL) {
        if (current->course_number == course_number && current->subject == subject) {
            if (previous == NULL) {
                collection->head = current->next;
            } else {
                previous->next = current->next;
            }
            total_credits -= current->credit_hours;
            free(current);
            return;
        }
        previous = current;
        current = current->next;
    }
    printf("Error: Course not found\n");
}

void free_memory(struct course_collection* collection) {
	/*
	This function will free all memory associated with the course_collection.
	*/
    struct courseNode* current = collection->head;
    struct courseNode* next_node;
    while (current != NULL) {
        next_node = current->next;
        free(current);
        current = next_node;
    }
    collection->head = NULL;
}

void schedule_save(struct course_collection* collection) {
	/*
	This function saves the contents of the CourseCollection to a CSV file.
	If the file already exists, it is overwritten.
	*/

	FILE* file = fopen("schedule.csv", "w");
	if (file == NULL) {
		printf("Error: Could not save schedule.\n");
		return;
	}
	struct courseNode* current = collection->head;
	fprintf(file, "Subject,Number,Teacher,Credits\n"); // CSV header
	while (current != NULL) {
		fprintf(file, "%s,%d,%s,%d\n", subject_to_string(current->subject), current->course_number, current->teacher, current->credit_hours);
		current = current->next;
	}
	fclose(file);
}

void schedule_load(struct course_collection* collection) {
    /*
    This function checks if a CSV data file exists and loads any courses that it specifies.
    Courses are sorted once the program finishes loading. It assumes that the file is in the format
    used by the schedule_save() function. If the file does not exist, it should do nothing.
    */
    FILE* file = fopen("schedule.csv", "r");
    if (file == NULL) {
        printf("No existing schedule to load.\n");
        return;
    }
    char line[1024];
    fgets(line, sizeof(line), file); // Skip the header line
    while (fgets(line, sizeof(line), file)) {
        char subject_str[4];
        char teacher[1024];
        int course_number, credit_hours;

        if (sscanf(line, "%3[^,],%d,%1023[^,],%d", subject_str, &course_number, teacher, &credit_hours) == 4) {
            struct courseNode* new_node = (struct courseNode*)malloc(sizeof(struct courseNode));
            new_node->subject = string_to_subject(subject_str);
            new_node->course_number = course_number;
            strcpy(new_node->teacher, teacher);
            new_node->credit_hours = credit_hours;
            new_node->next = NULL;
            insert_node(&collection->head, new_node);
            total_credits += new_node->credit_hours;
        } else {
            printf("Error: Invalid line in schedule file: %s", line);
        }
    }
    fclose(file);
}

void branching(char option) {
    switch (option) {
    case 'a':
        course_insert(&schedule);
        break;
    case 'd':
        course_drop(&schedule);
        break;
    case 's':
        schedule_print(&schedule);
        break;
    case 'q':
        schedule_save(&schedule);
        break;
    default:
        printf("\nError: Invalid Input.  Please try again...\n");
        break;
    }
}

int main() {
    char input_buffer;

    printf("\n\nWelcome to ASU Class Schedule\n");
    schedule_load(&schedule);

    //menu and input loop
    do {
        printf("\nMenu Options\n");
        printf("------------------------------------------------------\n");
        printf("a: Add a class\n");
        printf("d: Drop a class\n");
        printf("s: Show your classes\n");
        printf("q: Quit\n");
        printf("\nTotal Credits: %d\n\n", total_credits);
        printf("Please enter a choice ---> ");

        scanf(" %c", &input_buffer);

        branching(input_buffer);
    } while (input_buffer != 'q');

    free_memory(&schedule);

    return 0;
}
